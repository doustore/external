import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "OurStyle — Panel" },
      { name: "description", content: "Interfaz OurStyle en rojo, amarillo, negro y azul." },
      { property: "og:title", content: "OurStyle — Panel" },
      { property: "og:description", content: "Interfaz OurStyle en rojo, amarillo, negro y azul." },
    ],
  }),
  component: Index,
});

const TABS = {
  Principal: ["Opción cabeza", "Opción cuello", "Opción pecho", "Opción drag", "Modo precisión", "Modo rápido"],
  Visual: ["Brillo HUD", "Contorno de color", "Modo nocturno", "FPS boost"],
  Extra: ["Sensibilidad alta", "Vibración", "Sonido mejorado"],
} as const;
type Tab = keyof typeof TABS;

function Logo() {
  return (
    <div className="os-logo mx-auto flex h-28 w-28 items-center justify-center rounded-full">
      <span className="os-title text-4xl">OS</span>
    </div>
  );
}

function Toggle({ on, onClick }: { on: boolean; onClick: () => void }) {
  return (
    <button onClick={onClick} aria-pressed={on} className={`os-switch ${on ? "on" : ""}`}>
      <span />
    </button>
  );
}

function Index() {
  const [view, setView] = useState<"home" | "panel" | "credits">("home");
  const [showWelcome, setShowWelcome] = useState(true);
  const [game, setGame] = useState("");
  const [tab, setTab] = useState<Tab>("Principal");
  const [state, setState] = useState<Record<string, boolean>>({});

  return (
    <main className="os-bg min-h-screen px-5 py-10 text-foreground">
      {showWelcome && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/90 p-4 backdrop-blur-sm">
          <section className="w-full max-w-xl rounded-3xl border border-secondary/40 bg-zinc-950 p-4 shadow-2xl shadow-red-950/40">
            <div className="mb-3 text-center">
              <p className="os-title text-2xl">BIENVENIDO A OURSTYLE</p>
              <p className="mt-1 text-sm text-zinc-400">Mira nuestro video de bienvenida antes de entrar</p>
            </div>
            <video className="max-h-[65vh] w-full rounded-2xl bg-black object-contain" src="/welcome-video.mp4" autoPlay muted playsInline controls preload="auto" />
            <button onClick={() => setShowWelcome(false)} className="os-active mt-4 w-full rounded-xl px-5 py-4 text-base font-black transition-opacity hover:opacity-90">
              ENTRAR A OURSTYLE
            </button>
          </section>
        </div>
      )}
      <div className="mx-auto max-w-md">
        {view === "home" && (
          <>
            <Logo />
            <h1 className="os-title mt-6 text-center text-4xl">OURSTYLE</h1>
            <p className="mt-2 text-center text-muted-foreground">Selecciona tu versión</p>
            <div className="mt-8 space-y-4">
              {["VERSIÓN TH", "VERSIÓN MAX"].map((g) => (
                <button key={g} onClick={() => { setGame(g); setView("panel"); }} className="os-card flex w-full items-center gap-4 p-5 text-left">
                  <div className="os-dot h-14 w-14 rounded-full" />
                  <div className="flex-1">
                    <div className="text-lg font-black">{g}</div>
                    <div className="text-sm text-muted-foreground">Abrir panel de control</div>
                  </div>
                  <span className="text-2xl text-secondary">›</span>
                </button>
              ))}
              <div className="os-card flex items-center gap-4 p-5">
                <div className="flex h-14 w-14 items-center justify-center rounded-full bg-accent/20 text-2xl text-accent">●</div>
                <div className="flex-1 font-black">USUARIO</div>
                <span className="rounded-full border border-secondary/50 px-3 py-1 text-xs font-bold text-secondary">Sin expiración</span>
              </div>
            </div>
            <button onClick={() => setView("credits")} className="mx-auto mt-8 block text-muted-foreground">★ Créditos ›</button>
            <footer className="mt-10 text-center text-sm text-muted-foreground">
              <div className="font-bold text-secondary">OURSTYLE</div>
              <div>by @DylanXIT & @Jvztxn</div>
            </footer>
          </>
        )}

        {view === "panel" && (
          <>
            <button onClick={() => setView("home")} className="text-muted-foreground">‹ Volver</button>
            <h1 className="os-title mt-2 text-center text-3xl">Panel de control</h1>
            <p className="text-center font-bold text-secondary">● {game}</p>
            <p className="mt-2 text-center text-sm text-muted-foreground"><span className="text-accent">●</span> Sistema en línea</p>
            <div className="os-card mt-6 flex p-1">
              {(Object.keys(TABS) as Tab[]).map((t) => (
                <button key={t} onClick={() => setTab(t)} className={`flex-1 rounded-xl py-3 text-sm font-bold ${tab === t ? "os-active" : "text-muted-foreground"}`}>{t}</button>
              ))}
            </div>
            <div className="mt-5 space-y-3">
              {TABS[tab].map((item) => (
                <div key={item} className="os-card flex items-center gap-4 p-5">
                  <span className="text-xl text-primary">⌖</span>
                  <span className="flex-1 font-semibold">{item}</span>
                  <Toggle on={!!state[item]} onClick={() => setState((s) => ({ ...s, [item]: !s[item] }))} />
                </div>
              ))}
            </div>
          </>
        )}

        {view === "credits" && (
          <>
            <button onClick={() => setView("home")} className="text-muted-foreground">‹ Volver</button>
            <Logo />
            <h1 className="os-title mt-6 text-center text-4xl">CRÉDITOS</h1>
            <div className="mt-8 space-y-3">
              {[["@DylanXIT", "Developer & Designer"], ["@Jvztxn", "Co-Developer"], ["OurStyle Team", "Soporte & Testing"]].map(([n, r]) => (
                <div key={n} className="os-card p-5">
                  <div className="text-lg font-black text-secondary">{n}</div>
                  <div className="text-sm text-muted-foreground">{r}</div>
                </div>
              ))}
            </div>
          </>
        )}
      </div>
    </main>
  );
}
